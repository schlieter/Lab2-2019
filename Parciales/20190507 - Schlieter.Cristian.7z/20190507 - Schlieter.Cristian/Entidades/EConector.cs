﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public enum EConector
    {
        PCIExpress,
        USB,
        MiniUSB,
        MicroUSB,
        PS2
    }
}
